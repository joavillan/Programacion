package ej1;

import java.io.IOException;

public class test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		UsuarioyContrase�a.contrase�a();
	}

}
